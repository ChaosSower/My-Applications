﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание__5___Учебная_практика
{
    // Класс, содержащий функцию Main, которая запускает функции и выводит значения //
    class Task_5___Educational_Practice
    {
        /* Переменные

        // Математических и расчётных функций

        int N - количество строк трёхмерного массива
        int M - количество столбцов трёхмерного массива
        int K - количество страниц (слоёв) трёхмерного массива

        double[,,] arr - сам трёхмерный массив

        double Average - среднее значение элементов массива
        int ElementsAmount - количество элементов массива
        double Sum - сумма всех элементов массива
        double AverageValue - среднее значение элементов массива

        double Dispersion - дисперсия чисел первой строки массива

        int A1 - количество чисел, входящих в диапазон: [-100; -50]
        int A2 - количество чисел, входящих в диапазон: [-50; 0]
        int A3 - количество чисел, входящих в диапазон: [0; 50]
        int A4 - количество чисел, входящих в диапазон: [50; 100]

        int A5 - количество чисел, удовлетворяющих условию: < 0

        int A - минимальная граница случайного числа элемента массива
        int B - максимальная граница случайного числа элемента массива

        Random rand - переменная, отвечающая за выборку случайных чисел

        int i, int j, int k - стандартные переменные для циклов (а также - индекс страницы / столбца / строки)

        double S - сумма всех элементов массива
        int E - количество элементов массива
        double O - среднее значение элементов массива

        double C - сумма квадратов разницы между элементами первой строки массива и средним значением элементов массива
        double D - дисперсия чисел первой строки массива

        double F - заданный элемент массива

        double G - заданный элемент массива

        // Программных и системных функций

        bool SkipUserKeyToExit - переменная, позволяющая сразу после вывода справки запрпосить подтверждение на выход из программы
        ConsoleKeyInfo UserKey - считывание клавиши, которую ввёл пользователь

        int ArgumentIsCorrectTimes - количество верно введённых пользователем параметров массива

        ConsoleKeyInfo UserKeyToExit - считывание введённой пользователем клавиши для выхода из программы
        ConsoleKeyInfo UserConfirmToExit - считывание клавиши, подтверждающей выход из программы

        // Функций создания файла отчёта и записи результатов программы в текстовый файл

        char[] SymbolsException - массив, содержащий символы для исключения
        char[] LettersException - массив, содержащий буквы для исключения

        bool CommandToRecreateTextFile - переменная, отправляющая сигнал на перезапись данных файла отчёта при сохранении того же названия
        bool CorrectFileName - переменная, позволяющая создать файл отчёта, при условии, что имя текстового файла было введено пользователем корректно

        string FileText - текст файла отчёта

        string FileName - имя файла отчёта
        string FilePath - путь, по которому будет создан файл отчёта

        ConsoleKeyInfo UserKeyToRecreateTextFile - считывание клавиши, подтверждающей перезапись данных файла отчёта

        string FileNameOnRedaction - имя файла отчёта, которое проверяется на наличие исключительных символов
        char FileNameLetter - символ проверяемого имени файла отчёта

        */

        // Основная функция - в ней запускаются все функции, а также выводятся их значения //
        static void Main(string[] args)
        {
            Console.Title = "Программа для выполнения практического задания №5 - Евтюхин Кирилл из ИСП 121";

            int N = 0;
            int M = 0;
            int K = 0;

            Processing.HelpAndStart(out bool SkipUserKeyToExit);
            SkipUserKeyToExit = false; // сбрасывает значение для того, чтобы в конце корректно отображалось завершение работы при попытке выхода из программы, которая была совершена во время справки

            Console.WriteLine("Задайте 3-х мерный массив:");
            Processing.MassiveSizeInput(ref N, ref M, ref K);

            Console.WriteLine("Массив:");
            double[,,] arr = new double[K, N, M];
            MathFunctions.FillAndShowMatrix(arr);

            MathFunctions.FindSummAndAverage(arr, out double Average, out int ElementsAmount, out double Sum, out double AverageValue, ref N, ref M, ref K);
            MathFunctions.Dispersion(arr, out double Dispersion, Average, ElementsAmount);
            MathFunctions.FindNumbersByInterval(arr, out int A1, out int A2, out int A3, out int A4);
            MathFunctions.FindNumbersBellowZero(arr, out int A5);

            ConvertererToText.CreateTextFile(Sum, AverageValue, Dispersion, A1, A2, A3, A4, A5);

            Processing.CommandToExit(SkipUserKeyToExit);
        }

        // Класс, содержащий математические и расчётные функции //
        public class MathFunctions
        {
            // Функция, заполняющая элементы массива (матрицы) случайными числами
            public static void FillAndShowMatrix(double[,,] arr, int A = -1005, int B = 1105)
            {
                Console.WriteLine();

                Random rand = new Random();

                // Страница
                for (int i = 0; i < arr.GetLength(0); i++)
                {
                    Console.WriteLine("Страница №: " + (i + 1));

                    // Строка
                    for (int j = 0; j < arr.GetLength(1); j++)
                    {
                        // Столбец
                        for (int k = 0; k < arr.GetLength(2); k++)
                        {
                            arr[i, j, k] = rand.Next(A, B) / 10.0; // заполнение массива элементом, которое мы не видим

                            if ((k + 1) == arr.GetLength(2)) // анализ того, является ли заполняемый элемент массива последним в строке
                            {
                                Console.Write($"{arr[i, j, k]}"); // вывод на экран элемента массива, являющегося последним на строке
                            }

                            else
                            {
                                Console.Write($"{arr[i, j, k]} "); // вывод элемента массива на экран, при условии, что он не является последним на строке
                            }
                        }

                        Console.WriteLine();
                    }

                    Console.WriteLine();
                }
            }

            // Функция, которая находит сумму и среднее значение элементов массива
            public static void FindSummAndAverage(double[,,] arr, out double Average, out int ElementsAmount, out double Sum, out double AverageValue, ref int N, ref int M, ref int K, double S = 0)
            {
                for (int i = 0; i < arr.GetLength(0); i++)
                {
                    for (int j = 0; j < arr.GetLength(1); j++)
                    {
                        for (int k = 0; k < arr.GetLength(2); k++)
                        {
                            S += arr[i, j, k]; // нахождение суммы всех элементов массива
                        }
                    }
                }

                int E = N * M * K; // умножение количества строк, столбцов и страниц для вычисления объёма массива
                double O = S / E; // вычисление среднего арифметического по всем элементам массива
                Console.WriteLine($"Сумма всех чисел (S): {Math.Round(S, 2)}");
                Console.WriteLine($"Среднее значение (O): {Math.Round(O, 2)}");

                Average = O;
                ElementsAmount = E;

                Sum = S;
                AverageValue = O;
            }

            // Функция, которая находит дисперсию элементов первой строки массива
            public static void Dispersion(double[,,] arr, out double Dispersion, double Average, int ElementsAmount, double C = 0)
            {
                for (int i = 0; i < 1; i++)
                {
                    for (int j = 0; j < 1; j++)
                    {
                        for (int k = 0; k < arr.GetLength(2); k++)
                        {
                            C += Math.Pow(arr[i, j, k] - Average, 2); // вычисление суммы квадратов разницы между элементами первой строки и средним значением массива
                        }
                    }
                }

                double D = C / (ElementsAmount - 1); // вычисление дисперсии элементов первой строки
                Console.WriteLine($"Дисперсия (D): {Math.Round(D, 3)}"); // нужно иметь в виду, что в сотых долях будет погрешность (поскольку это допускает сам тип данных double)!

                Dispersion = D;
            }

            // Функция, которая находит числа в заданных интервалах
            public static void FindNumbersByInterval(double[,,] arr, out int A1, out int A2, out int A3, out int A4, int a1 = 0, int a2 = 0, int a3 = 0, int a4 = 0)
            {
                for (int i = 0; i < arr.GetLength(0); i++)
                {
                    for (int j = 0; j < arr.GetLength(1); j++)
                    {
                        for (int k = 0; k < arr.GetLength(2); k++)
                        {
                            double F = arr[i, j, k]; // извлечение значения элемента массива

                            if ((-100 <= F) && (F <= -50))
                            {
                                a1++;
                            }

                            if ((-50 <= F) && (F <= 0))
                            {
                                a2++;
                            }

                            if ((0 <= F) && (F <= 50))
                            {
                                a3++;
                            }

                            if ((50 <= F) && (F <= 100))
                            {
                                a4++;
                            }
                        }
                    }
                }

                Console.WriteLine($"Кол-во чисел в интервале [-100; -50]: {a1}");
                Console.WriteLine($"Кол-во чисел в интервале [-50; 0]: {a2}");
                Console.WriteLine($"Кол-во чисел в интервале [0; 50]: {a3}");
                Console.WriteLine($"Кол-во чисел в интервале [50; 100]: {a4}");

                A1 = a1;
                A2 = a2;
                A3 = a3;
                A4 = a4;
            }

            // Функция, которая считает числа, удовлетворяющие условию
            public static void FindNumbersBellowZero(double[,,] arr, out int A5, int a5 = 0)
            {
                for (int i = 0; i < arr.GetLength(0); i++)
                {
                    for (int j = 0; j < arr.GetLength(1); j++)
                    {
                        for (int k = 0; k < arr.GetLength(2); k++)
                        {
                            double G = arr[i, j, k]; // извлечение значения элемента массива

                            if (G < 0)
                            {
                                a5++;
                            }
                        }
                    }
                }

                Console.WriteLine($"Кол-во чисел меньше 0: {a5}");

                A5 = a5;
            }
        }

        // Класс, содержащий программные и системные функции //
        public class Processing
        {
            // Функция, вызывающая справку, которая также не позволяет пользователю вводить некорректные символы во избежание ошибок (обрабатывает исключения)
            public static void HelpAndStart(out bool SkipUserKeyToExit)
            {
                SkipUserKeyToExit = false; // принимает значение для запроса подтверждения выхода сразу после справки

                Console.WriteLine("Для просмотра сведений о программе, поставленных перед ней задач, а также инструкции нажмите клавишу F1" +
                    "\nЕсли это не требуется, нажмите клавишу Enter" +
                    "\nДля выхода из программы нажмите клавишу Esc");

                ConsoleKeyInfo UserKey = Console.ReadKey(true); // считывание нажатой пользователем клавиши

                if (UserKey.Key == ConsoleKey.F1)
                {
                    Console.WriteLine("\nЗадание №5 - 'Массив', Выполнил - Евтюхин Кирилл из ИСП 121" +
                                      "\n\n Задачи:\n" +
                                      "\n1) Программа строит массив по заданным пользователем параметрам;" +
                                      "\n2) Программа находит сумму всех элементов массива;" +
                                      "\n3) Программа рассчитывает среднее значение всех элементов массива;" +
                                      "\n4) Программа вычисляет дисперсию элементов первой строки массива;" +
                                      "\n5) Программа считает количество чисел массива, попадающих в заданные интервалы ([-100; -50], [-50; 0], [0; 50], [50; 100]);" +
                                      "\n6) Программа складывает количество элементов массива, удовлетворяющих заданному условию (< 0);" +
                                      "\n7)" + @" Программа создаёт файл отчёта с указанным пользователем названием и открывает его для записи данных по пути S:\PRACTICA\Евтюхин К. О\Задание №5 - Учебная практика;" +
                                      "\n8) Программа автоматически записывает результаты выполнения функций в только что созданный пользователем файл отчёта, который затем автоматически закрывается;" +
                                      "\n9) Программа заканчивает свою работу при нажатии пользователем клавиши Esc и последующем подтверждении выхода клавишей Enter." +
                                      "\n\n Инструкция:\n" +
                                      "\n1) Введите параметры для создания массива;" +
                                      "\n2) Введите название файла отчёта, в который будут записаны результаты выполнения алгоритма;" +
                                      "\n3) Если файл отчёта с указанным именем уже существует, то подтвердите перезапись данных с помощью клавиши Enter, или же выберите другое название после нажатия клавиши Esc;" +
                                      "\n4) Для выхода из программы нажмите клавишу Esc во время вывода справки или по завершению алгоритма программы, затем подтвердите выбор нажатием на клавишу Enter.");
                    Console.WriteLine();
                }

                else if (UserKey.Key == ConsoleKey.Enter)
                {
                    Console.WriteLine();
                }

                else if (UserKey.Key == ConsoleKey.Escape)
                {
                    SkipUserKeyToExit = true;
                    CommandToExit(SkipUserKeyToExit);
                    return;
                }

                else
                {
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine("Пожалуйста, нажмите клавишу F1 для вывода справки, или клавишу Enter для продолжения выполнения хода программы, или Esc для выхода из программы.");
                    HelpAndStart(out SkipUserKeyToExit);
                    return;
                }
            }

            // Функция, принимающая на вход параметры массива, которая также проверяет правильность введённых данных (обрабатывает исключения)
            public static void MassiveSizeInput(ref int N, ref int M, ref int K)
            {
                int ArgumentIsCorrectTimes = 0; // переменная, считающая сколько введено верных параметров массива

                while (ArgumentIsCorrectTimes != 3) // запрашивает параметры массива до тех пор, пока каждый из них не будет введён корректно
                {
                    while (ArgumentIsCorrectTimes == 0)
                    {
                        Console.WriteLine();
                        Console.WriteLine("Введите кол-во строк (N):");

                        try
                        {
                            N = int.Parse(Console.ReadLine()); // кол-во строк массива

                            if ((N <= 0) || (N > 1000))
                            {
                                throw new Exception();
                            }

                            else if (N is int)
                            {
                                ArgumentIsCorrectTimes++;
                            }
                        }

                        catch (System.FormatException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Формат числа задан некорректно. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }

                        catch (System.OverflowException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Введено число, превышающее лимит типа int. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }

                        catch (Exception)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Введено число, не подходящее для создания массива. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }
                    }

                    while (ArgumentIsCorrectTimes == 1)
                    {
                        Console.WriteLine();
                        Console.WriteLine("Введите кол-во столбцов (M):");

                        try
                        {
                            M = int.Parse(Console.ReadLine()); // кол-во столбцов массива

                            if ((M <= 0) || (M > 1000))
                            {
                                throw new Exception();
                            }

                            else if (M is int)
                            {
                                ArgumentIsCorrectTimes++;
                            }
                        }

                        catch (System.FormatException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Формат числа задан некорректно. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }

                        catch (System.OverflowException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Введено число, превышающее лимит типа int. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }

                        catch (Exception)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Введено число, не подходящее для создания массива. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }
                    }

                    while (ArgumentIsCorrectTimes == 2)
                    {
                        Console.WriteLine();
                        Console.WriteLine("Введите кол-во страниц (K):");

                        try
                        {
                            K = int.Parse(Console.ReadLine()); // кол-во страниц массива

                            if ((K <= 0) || (K > 1000))
                            {
                                throw new Exception();
                            }

                            else if (K is int)
                            {
                                ArgumentIsCorrectTimes++;
                            }
                        }

                        catch (System.FormatException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Формат числа задан некорректно. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }

                        catch (System.OverflowException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Введено число, превышающее лимит типа int. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }

                        catch (Exception)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Введено число, не подходящее для создания массива. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }
                    }
                }

                Console.WriteLine();
            }

            // Функция, выполняющая выход из программы при подтверждении выбора пользователем
            public static void CommandToExit(bool SkipUserKeyToExit)
            {
                Console.WriteLine();

                if (!SkipUserKeyToExit)
                {
                    Console.WriteLine("Программа завершила свою работу. Для выхода нажмите клавишу Esc.");
                    Console.WriteLine();

                    ConsoleKeyInfo UserKeyToExit = Console.ReadKey(true); // считывание нажатой пользователем клавиши для выхода из программы

                    while (UserKeyToExit.Key != ConsoleKey.Escape) // запрашивает нажатие клавиши до тех пор, пока не будет введена клавиша Escape
                    {
                        UserKeyToExit = Console.ReadKey(true);
                    }

                    if (UserKeyToExit.Key == ConsoleKey.Escape)
                    {
                        Console.WriteLine("Вы уверены, что хотите выйти из программы? Подтвердите выход из программы нажатием на клавишу Enter. Для того, чтобы вернуться, нажмите клавишу Esc.");

                        ConsoleKeyInfo UserConfirmToExit = Console.ReadKey(true); // считывание нажатой пользователем клавиши для подтверждения выхода из программы

                        while ((UserConfirmToExit.Key != ConsoleKey.Escape) && (UserConfirmToExit.Key != ConsoleKey.Enter)) // предотвращает нажатие посторонних клавиш пользователем
                        {
                            UserConfirmToExit = Console.ReadKey(true);
                        }

                        if (UserConfirmToExit.Key == ConsoleKey.Enter)
                        {
                            Environment.Exit(0);
                        }

                        else if (UserConfirmToExit.Key == ConsoleKey.Escape)
                        {
                            CommandToExit(SkipUserKeyToExit);
                            return;
                        }
                    }
                }

                if (SkipUserKeyToExit)
                {
                    Console.WriteLine("Вы уверены, что хотите выйти из программы? Подтвердите выход из программы нажатием на клавишу Enter. Для того, чтобы вернуться, нажмите клавишу Esc.");

                    ConsoleKeyInfo UserConfirmToExit = Console.ReadKey(true);

                    while ((UserConfirmToExit.Key != ConsoleKey.Escape) && (UserConfirmToExit.Key != ConsoleKey.Enter))
                    {
                        UserConfirmToExit = Console.ReadKey(true);
                    }

                    if (UserConfirmToExit.Key == ConsoleKey.Enter)
                    {
                        Environment.Exit(0);
                    }

                    else if (UserConfirmToExit.Key == ConsoleKey.Escape)
                    {
                        Console.WriteLine();
                        HelpAndStart(out SkipUserKeyToExit);
                        return;
                    }
                }
            }
        }

        // Класс, содержащий функции создания файла отчёта и записи результатов программы в текстовый файл //
        public class ConvertererToText
        {
            // Класс, содержащий перехваты исключительных ошибок при вводе пользователем неверного имени файла отчёта //
            public class ErrorCatcherInTextFileName
            {
                public class NameIsEmptyException : Exception
                {
                    public NameIsEmptyException(string message) : base("Пустое имя файла.")
                    {

                    }
                }

                public class NameIsOutOfRangeException : Exception
                {
                    public NameIsOutOfRangeException(string message) : base("Имя файла превышает 200 символов.")
                    {

                    }
                }

                public class NameContainsNonlatinicLettersException : Exception
                {
                    public NameContainsNonlatinicLettersException(string message) : base("Имя содержит посторонние символы.")
                    {

                    }
                }
            }

            // Функция, создающая текстовый файл отчёта с именем, введённым пользователем, которая также не позволяет пользователю вводить некорректные символы во избежание ошибок (обрабатывает исключения)
            public static void CreateTextFile(double Sum, double AverageValue, double Dispersion, int A1, int A2, int A3, int A4, int A5)
            {
                char[] SymbolsException = new char[] {'`', '~', '!', '@', '"', '#', '№', '$', ';', '%', '^', ':', '&', '?', '*', '(', ')', '-', '_', '=', '+', (char)92, (char)124, '/', '[', '{', ']', '}', (char)39, ',', '<', '.', '>'};
                char[] LettersException = new char[] {'А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ы', 'Ь', 'Э', 'Ю', 'Я'};

                bool CommandToRecreateTextFile = false;
                bool CorrectFileName = false;

                string FileText = "Задание №5 - 'Массив', Выполнил - Евтюхин Кирилл из ИСП 121" +
                    Environment.NewLine + $"Сумма всех чисел S = {Math.Round(Sum, 2)}" +
                    Environment.NewLine + $"Среднее значение O = {Math.Round(AverageValue, 2)}" +
                    Environment.NewLine + $"Дисперсия D = {Math.Round(Dispersion, 3)}" +
                    Environment.NewLine + $"Количество чисел в интервале [-100; -50]: {A1}" +
                    Environment.NewLine + $"Количество чисел в интервале [-50; 0]: {A2}" +
                    Environment.NewLine + $"Количество чисел в интервале [0; 50]: {A3}" +
                    Environment.NewLine + $"Количество чисел в интервале [50; 100]: {A4}" +
                    Environment.NewLine + $"Количество чисел меньше 0: {A5}";

                if (!CommandToRecreateTextFile)
                {
                    Console.WriteLine();
                    Console.WriteLine("Введите имя текстового файла отчёта латинскими буквами:");

                    while (CorrectFileName == false) // запрашивает имя файла до тех пор, пока оно не будет введено корректно
                    {
                        try
                        {
                            string FileName = Console.ReadLine(); // считывание имени файла отчёта
                            string FilePath = @$"S:\PRACTICA\Евтюхин К. О\Задание №5 - Учебная практика\{FileName}.txt"; // считывание пути файла отчёта для его создания

                            if (File.Exists(FilePath) && FileName.Length != 0)
                            {
                                Console.WriteLine();
                                Console.WriteLine("Файл с таким же именем уже существует в этом расположении. Вы хотите перезаписать данные файла? Для подтверждения нажмите клавишу Enter, для отмены нажмите клавишу Esc.");

                                ConsoleKeyInfo UserKeyToRecreateTextFile = Console.ReadKey(); // считывание нажатой пользователем клавиши для перезаписи данных файла отчёта

                                while ((UserKeyToRecreateTextFile.Key != ConsoleKey.Escape) && (UserKeyToRecreateTextFile.Key != ConsoleKey.Enter))
                                {
                                    UserKeyToRecreateTextFile = Console.ReadKey(true);
                                }

                                if (UserKeyToRecreateTextFile.Key == ConsoleKey.Enter)
                                {
                                    CommandToRecreateTextFile = true;
                                    File.WriteAllText(FilePath, FileText);
                                    return;
                                }

                                else if (UserKeyToRecreateTextFile.Key == ConsoleKey.Escape)
                                {
                                    CreateTextFile(Sum, AverageValue, Dispersion, A1, A2, A3, A4, A5);
                                    return;
                                }
                            }

                            else if (FileName.Length == 0)
                            {
                                throw new ErrorCatcherInTextFileName.NameIsEmptyException("");
                            }

                            else if (FileName.Length > 200)
                            {
                                throw new ErrorCatcherInTextFileName.NameIsOutOfRangeException("");
                            }

                            // Обработка имени файла отчёта для проверки на исключительные символы (обработка ошибок)

                            string FileNameOnRedaction = FileName.ToUpper();
                            int j = 0;

                            for (int i = 0; i < FileName.Length; i++)
                            {
                                char FileNameLetter = FileNameOnRedaction[j];

                                foreach (char x in SymbolsException)
                                {
                                    if (FileNameLetter == x)
                                    {
                                        throw new ErrorCatcherInTextFileName.NameContainsNonlatinicLettersException("");
                                    }
                                }

                                foreach (char x in LettersException)
                                {
                                    if (FileNameLetter == x)
                                    {
                                        throw new ErrorCatcherInTextFileName.NameContainsNonlatinicLettersException("");
                                    }
                                }

                                j++;
                            }

                            File.WriteAllText(FilePath, FileText);

                            CorrectFileName = true;
                        }

                        catch (ErrorCatcherInTextFileName.NameIsEmptyException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Вы не ввели имя текстового файла. Пожалуйста, введите имя текстового файла отчёта латинскими буквами (не больше 200 символов).");
                        }

                        catch (ErrorCatcherInTextFileName.NameIsOutOfRangeException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Имя текстового файла слишком длинное. Пожалуйста, введите имя текстового файла отчёта латинскими буквами (не больше 200 символов).");
                        }

                        catch (ErrorCatcherInTextFileName.NameContainsNonlatinicLettersException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("В имени текстового файла присутствуют буквы и/или символы не из латинского алфавита. Пожалуйста, введите имя текстового файла отчёта латинскими буквами (не больше 200 символов).");
                        }
                    }
                }
            }
        }
    }
}