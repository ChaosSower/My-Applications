import pygame

# Размеры окна
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

# Загрузка картинки заднего фона и персонажа
player = pygame.image.load("idle.png")
bg = pygame.image.load("background.jpg")


# Поведение игрока
class Player(pygame.sprite.Sprite):
    right = True  # переменная нужна для того, чтобы игрок при старте смотрел вправо

    # Методы
    def __init__(self):
        super().__init__()  # стандартный конструктор класса с вызовом родительского

        self.image = pygame.image.load("idle.png")  # создание изображения игрока

        self.rect = self.image.get_rect()

        # Векторы скорости
        self.change_x = 0
        self.change_y = 0

        self.level = None

    def update(self):
        self.calculate_gravitation()  # гравитация игрока

        self.rect.x += self.change_x  # функция изменения положения игрока по горизонтали

        # Индикатор столкновения с объектом
        block_hit_list = pygame.sprite.spritecollide(self, self.level.platform_list, False)

        # Перебор всех возможных объектов, с которыми возможно столкнуться по горизонтали
        for block in block_hit_list:
            if self.change_x > 0:
                self.rect.right = block.rect.left
            elif self.change_x < 0:
                self.rect.left = block.rect.right

        self.rect.y += self.change_y  # функция изменения положения игрока по вертикали

        # Перебор всех возможных объектов, с которыми возможно столкнуться по вертикали
        block_hit_list = pygame.sprite.spritecollide(self, self.level.platform_list, False)
        for block in block_hit_list:
            if self.change_y > 0:
                self.rect.bottom = block.rect.top
            elif self.change_y < 0:
                self.rect.top = block.rect.bottom

            # Остановка вертикального движения
            self.change_y = 0

    # Установка быстроты падения объекта под действием гравитации
    def calculate_gravitation(self):
        if self.change_y == 0:
            self.change_y = 1
        else:
            self.change_y += .95

        if self.rect.y >= SCREEN_HEIGHT - self.rect.height and self.change_y >= 0:  # если уже на земле
            self.change_y = 0
            self.rect.y = SCREEN_HEIGHT - self.rect.height

    # Обработка прыжка
    def jump(self):
        self.rect.y += 10
        platform_hit_list = pygame.sprite.spritecollide(self, self.level.platform_list, False)
        self.rect.y -= 10

        # Если все в порядке, прыгаем вверх
        if len(platform_hit_list) > 0 or self.rect.bottom >= SCREEN_HEIGHT:
            self.change_y = -16

    # Передвижение игрока
    def go_left(self):
        self.change_x = -9
        if (self.right):  # проверяем куда он смотрит и если что, то переворачиваем его
            self.flip()
            self.right = False

    def go_right(self):
        self.change_x = 9
        if (not self.right):
            self.flip()
            self.right = True

    # Метод, когда не происходит нажатие клавиш
    def stop(self):
        self.change_x = 0

    # Зеркальное отражение изображения игрока
    def flip(self):
        self.image = pygame.transform.flip(self.image, True, False)


# Класс для описания платформы
class Platform(pygame.sprite.Sprite):
    def __init__(self, width, height):
        # Конструктор платформ
        super().__init__()

        self.image = pygame.image.load('platform.png')  # загрузка изображения платформы

        self.rect = self.image.get_rect  # ссылка на изображение прямоугольника


# Класс расстановки платформ на поле
class Level(object):
    def __init__(self):
        self.platform_list = None
        self.platforms = pygame.sprite.Group()  # группа спрайтов
        self.player = player  # ссылка на нового игрока

        self.background = None

    # Обновление экрана
    def update(self):
        self.platform_list.update()

    # Метод для рисования объектов на сцене
    def draw(self, screen):
        screen.blit(bg, (0, 0))  # отрисовка заднего фона

        self.platform_list.draw(screen)  # отрисовка всех платформ из группы спрайтов


# Класс, описывающий где будут находиться все платформы на определенном уровне игры
class Level01(Level):
    def __init__(self, player):
        Level.__init__(player)  # вызов родительского конструктора

        # Массив с данными платформы. Данные в таком формате:
        level = [
            [210, 32, 500, 500],  # ширина, высота, x и y позиция
            [210, 32, 200, 400],
            [210, 32, 600, 300],
        ]

        # Перебираем массив и добавляем каждую платформу в группу спрайтов - platform_list
        for platform in level:
            block = Platform(platform[0], platform[1])
            block.rect.x = platform[2]
            block.rect.y = platform[3]
            block.player = self.player
            self.platform_list.add(block)


# Запуск программы
def main():
    # Инициализация
    pygame.init()

    # Установка высоты и ширины
    size = [SCREEN_WIDTH, SCREEN_HEIGHT]
    screen = pygame.display.set_mode(size)

    # Название игры
    pygame.display.set_caption("2-D платформер на Python")

    # Создание игрока
    player = Player()

    # Создание всех уровней
    level_list = [Level01(player)]

    # Установка текущего уровня
    current_level_no = 0
    current_level = level_list[current_level_no]

    active_sprite_list = pygame.sprite.Group()
    player.level = current_level

    player.rect.x = 340
    player.rect.y = SCREEN_HEIGHT - player.rect.height
    active_sprite_list.add(player)

    done = False  # выполнение программы до закрытия пользователем

    # Скорость обновления экрана
    clock = pygame.time.Clock()

    # Основной цикл программы
    while not done:
        # Отслеживание действий
        for event in pygame.event.get():
            if event.type == pygame.QUIT:  # если пользователь закрыл программу, то цикл останавливается
                done = True

            # Движение игрока по нажатию на клавиши
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    player.go_left()
                if event.key == pygame.K_RIGHT:
                    player.go_right()
                if event.key == pygame.K_UP:
                    player.jump()

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT and player.change_x < 0:
                    player.stop()
                if event.key == pygame.K_RIGHT and player.change_x > 0:
                    player.stop()

        # Обновление спрайта игрока
        active_sprite_list.update()

        # Обновление объектов на сцене
        current_level.update()

        # Правая граница
        if player.rect.right > SCREEN_WIDTH:
            player.rect.right = SCREEN_WIDTH

        # левая граница
        if player.rect.left < 0:
            player.rect.left = 0

        # Отрисовка объектов
        current_level.draw(screen)
        active_sprite_list.draw(screen)

        # FPS
        clock.tick(30)

        # Обновление экрана после отрисовки объектов
        pygame.display.flip()

    # Закрытие программы
    pygame.quit()


main()
