from selenium import webdriver

browser = webdriver.Chrome('/Users/evtyk/Downloads/chromedriver_win32/chromedriver.exe')
browser.get("https://www.youtube.com/")
