from watchdog.observers import Observer
import os
import time
from watchdog.events import FileSystemEventHandler


# Класс, в котором происходит сортировка файлов
class Handler(FileSystemEventHandler):
    def on_modified(self, event):
        for filename in os.listdir(folder_track):
            extension = filename.split(".")
            if len(extension) > 1 and (
                    extension[1].lower() == "jpg" or extension[1].lower() == "png" or extension[1].lower() == "mp4"):
                file = folder_track + "/" + filename
                new_path = default_folder_destination + "/" + filename
                os.rename(file, new_path)


# Стандартные пути сортировки
default_folder_track = 'C:/Users/Public/Downloads'
default_folder_destination = 'C:/Users/Public/Pictures'

# Приветствие
print("""Доброго времени суток! Данная программа предназначена для сортировки файлов по их форматам.
На данный момент это касается лишь форматов 'jpg', 'png', 'mp4'.
Обратите внимание на то, что алгоритм сортировки будет применяться только к тем файлам,
которые были затронуты после запуска программы!""")

# Ввод пути сортировки
folder_track = input("""Пожалуйста, введите путь, откуда будет производится сортировка файлов.
В случае, если вы ничего не введёте, будет выбрана папка 'Общие загруженные файлы': """)

# Ограничение пустого ввода
while folder_track.isspace():
    folder_track = input("Вы ввели пустое поле! Пожалуйста, введите путь или нажмите клавишу 'Enter': ")

if not folder_track:
    folder_track = default_folder_track
    print("Выбрана папка по умолчанию 'Общие загруженные файлы'")

else:
    print("Выбран ваш путь:", folder_track)

handle = Handler()
observer = Observer()
observer.schedule(handle, folder_track, recursive=True)
observer.start()

try:
    while True:
        time.sleep(10)

except KeyboardInterrupt:
    observer.stop()

observer.join()
