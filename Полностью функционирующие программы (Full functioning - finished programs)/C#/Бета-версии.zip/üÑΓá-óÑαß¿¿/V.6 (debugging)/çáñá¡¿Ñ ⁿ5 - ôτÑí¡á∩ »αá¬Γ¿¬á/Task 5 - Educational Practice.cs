﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание__5___Учебная_практика
{
    // Класс, содержащий функцию Main, которая запускает функции и выводит значения //
    class Task_5___Educational_Practice
    {
        /* Переменные

        // Математических и расчётных функций

        int N - количество строк тёхмерного массива
        int M - количество столбцов тёхмерного массива
        int K - количество страниц (слоёв) трёхмерного массива

        double Average - среднее значение элементов массива
        int Elementsamount - количество элементов массива

        double Sum - сумма всех элементов массива
        double AverageValue - среднее значение элементов массива

        double Dispersion - дисперсия чисел первой строки массива

        int A1 - количество чисел, входящих в диапазон: [-100; -50]
        int A2 - количество чисел, входящих в диапазон: [-50; 0]
        int A3 - количество чисел, входящих в диапазон: [0; 50]
        int A4 - количество чисел, входящих в диапазон: [50; 100]

        int A5 - количество чисел, удовлетворяющих условию: < 0

        double[,,] arr - сам трёхмерный массив

        int A - минимальная граница случайного числа элемента массива
        int B - максимальная граница случайного числа элемента массива

        Random rand - переменная, отвечающая за выборку случайных чисел

        int i, int j, int k - стандартные переменные для циклов (а также - индекс страницы / столбца / строки)

        double S - сумма всех элементов массива
        int E - количество элементов массива
        double O - среднее значение элементов массива

        double C - сумма квадратов разницы между элементами первой строки массива и средним значением элементов массива
        double D - дисперсия чисел первой строки массива

        double F - заданный элемент массива

        double G - заданный элемент массива

        // Программных и системных функций

        bool SkipUserKeyToExit - переменная, позволяющая сразу после вывода справки запрпосить подтверждение выхода из программы
        ConsoleKeyInfo UserKey - считывание клавиши, которую ввёл пользователь

        int ArgumentIsCorrectTimes - количество верно введённых пользователем параметров массива

        ConsoleKeyInfo UserKeyToExit - считывание введённой пользователем клавиши для выхода из программы
        ConsoleKeyInfo UserConfirmToExit - считывание клавиши, подтверждающей выход из программы

        */

        // Основная функция - в ней запусаются все функции, а также выводятся их начения //
        static void Main(string[] args)
        {
            Console.Title = "Программа для выполнения практического задания №5 - Евтюхин Кирилл из ИСП 121";

            bool SkipUserKeyToExit;

            int N = 0;
            int M = 0;
            int K = 0;

            double Average;
            int ElementsAmount;

            double Sum;
            double AverageValue;

            double Dispersion;

            int A1;
            int A2;
            int A3;
            int A4;

            int A5;

            string FileName = "";

            Processing.HelpAndStart(out SkipUserKeyToExit);
            SkipUserKeyToExit = false; // Сбрасывает значение для того, чтобы в конце корректно отображалось завершение работы при попытке выхода из программы во время справки

            Console.WriteLine("Задайте 3-х мерный массив:");
            Processing.MassiveSizeInput(ref N, ref M, ref K);

            Console.WriteLine("Массив:");
            double[,,] arr = new double[K, N, M];
            MathFunctions.FillAndShowMatrix(arr);

            MathFunctions.FindSummAndAverage(arr, out Average, out ElementsAmount, out Sum, out AverageValue, ref N, ref M, ref K);
            MathFunctions.Dispersion(arr, out Dispersion, Average, ElementsAmount);
            MathFunctions.NumbersByInterval(arr, out A1, out A2, out A3, out A4);
            MathFunctions.NumbersBellowZero(arr, out A5);

            ConvertererToText.CreateTextFile(Sum, AverageValue, Dispersion, A1, A2, A3, A4, A5, FileName);

            Processing.CommandToExit(SkipUserKeyToExit);
        }

        // Класс, содержащий математические и расчётные функции //
        public class MathFunctions
        {
            // Функция, заполняющая элементы массива (матрицы) случайными числами
            public static void FillAndShowMatrix(double[,,] arr, int A = -1005, int B = 1105)
            {
                Console.WriteLine();

                Random rand = new Random();

                // Страница
                for (int i = 0; i < arr.GetLength(0); i++)
                {
                    Console.WriteLine("Страница №: " + (i + 1));

                    // Строка
                    for (int j = 0; j < arr.GetLength(1); j++)
                    {
                        // Столбец
                        for (int k = 0; k < arr.GetLength(2); k++)
                        {
                            arr[i, j, k] = rand.Next(A, B) / 10.0; // заполнение массива элементом, которое мы не видим

                            if ((k + 1) == arr.GetLength(2)) // анализ того, является ли заполняемый элемент массива последним в строке
                            {
                                Console.Write($"{arr[i, j, k]}"); // вывод на экран элемента массива, являющегося последним на строке
                            }

                            else
                            {
                                Console.Write($"{arr[i, j, k]} "); // вывод элемента массива на экран, при условии, что он не является последнем на строке
                            }
                        }

                        Console.WriteLine();
                    }

                    Console.WriteLine();
                }
            }

            // Функция, которая находит сумму и среднее значение элементов массива
            public static void FindSummAndAverage(double[,,] arr, out double Average, out int ElementsAmount, out double Sum, out double AverageValue, ref int N, ref int M, ref int K, double S = 0)
            {
                for (int i = 0; i < arr.GetLength(0); i++)
                {
                    for (int j = 0; j < arr.GetLength(1); j++)
                    {
                        for (int k = 0; k < arr.GetLength(2); k++)
                        {
                            S += arr[i, j, k]; // нахождение суммы всех элементов массива
                        }
                    }
                }

                int E = N * M * K; // умножение количества строк, столбцов и страниц для вычисления объёма массива
                double O = S / E; // вычисление среднего арифметического по всем элементам массива
                Console.WriteLine($"Сумма всех чисел (S): {Math.Round(S, 2)}");
                Console.WriteLine($"Среднее значение (O): {Math.Round(O, 2)}");

                Average = O;
                ElementsAmount = E;

                Sum = S;
                AverageValue = O;
            }

            // Функция, которая находит дисперсию элементов первой строки массива
            public static void Dispersion(double[,,] arr, out double Dispersion, double Average, int ElementsAmount, double C = 0)
            {
                for (int i = 0; i < 1; i++)
                {
                    for (int j = 0; j < 1; j++)
                    {
                        for (int k = 0; k < arr.GetLength(2); k++)
                        {
                            C += Math.Pow(arr[i, j, k] - Average, 2); // вычисление суммы квадратов разницы между элементами первой строки и средним значением массива
                        }
                    }
                }

                double D = C / (ElementsAmount - 1); // вычисление дисперсии элементов первой строки
                Console.WriteLine($"Дисперсия (D): {Math.Round(D, 3)}"); // Нужно иметь в виду, что в сотых долях будет погрешность (поскольку это допускает сам тип данных double)!

                Dispersion = D;
            }

            // Функция, которая находит числа в заданных интервалах
            public static void NumbersByInterval(double[,,] arr, out int A1, out int A2, out int A3, out int A4, int a1 = 0, int a2 = 0, int a3 = 0, int a4 = 0)
            {
                for (int i = 0; i < arr.GetLength(0); i++)
                {
                    for (int j = 0; j < arr.GetLength(1); j++)
                    {
                        for (int k = 0; k < arr.GetLength(2); k++)
                        {
                            double F = arr[i, j, k]; // извлечение значения элемента массива

                            if ((-100 <= F) && (F <= -50))
                            {
                                a1++;
                            }

                            if ((-50 <= F) && (F <= 0))
                            {
                                a2++;
                            }

                            if ((0 <= F) && (F <= 50))
                            {
                                a3++;
                            }

                            if ((50 <= F) && (F <= 100))
                            {
                                a4++;
                            }
                        }
                    }
                }

                Console.WriteLine($"Кол-во чисел в интервале [-100; -50]: {a1}");
                Console.WriteLine($"Кол-во чисел в интервале [-50; 0]: {a2}");
                Console.WriteLine($"Кол-во чисел в интервале [0; 50]: {a3}");
                Console.WriteLine($"Кол-во чисел в интервале [50; 100]: {a4}");

                A1 = a1;
                A2 = a2;
                A3 = a3;
                A4 = a4;
            }

            // Функция, которая считает числа, удовлетворяющие условию
            public static void NumbersBellowZero(double[,,] arr, out int A5, int a5 = 0)
            {
                for (int i = 0; i < arr.GetLength(0); i++)
                {
                    for (int j = 0; j < arr.GetLength(1); j++)
                    {
                        for (int k = 0; k < arr.GetLength(2); k++)
                        {
                            double G = arr[i, j, k]; // извлечение значения элемента массива

                            if (G < 0)
                            {
                                a5++;
                            }
                        }
                    }
                }

                Console.WriteLine($"Кол-во чисел меньше 0: {a5}");

                A5 = a5;
            }
        }

        // Класс, содержащий программные и системные функции //
        public class Processing
        {
            // Функция, вызывающая справку, которая также не позволяет пользователю вводить некорректные символы во избежания ошибок (функция, обрабатывающая исключения)
            public static void HelpAndStart(out bool SkipUserKeyToExit)
            {
                SkipUserKeyToExit = false; // принимает значение для обхода двойного ожидания ввода пользователем клавиши

                Console.WriteLine("Для просмотра сведений о программе, поставленных перед ней задач, а также интструкции нажмите клавишу F1" +
                    "\nЕсли это не требуется, нажмите клавишу Enter" +
                    "\nДля выхода из программы нажмите клавишу Esc");

                ConsoleKeyInfo UserKey = Console.ReadKey(true); // считывание нажатой пользователем клавиши

                if (UserKey.Key == ConsoleKey.F1)
                {
                    Console.WriteLine("\nЗадание №5 - 'Массив', Выполнил - Евтюхин кирилл из ИСП 121" +
                                      "\n\n Задачи:\n" +
                                      "\n1) Программа строит массив по заданным пользователем параметрам;" +
                                      "\n2) Программа находит сумму всех элементов массива;" +
                                      "\n3) Программа расчитывает среднее значение всех элементов массива;" +
                                      "\n4) Программа вычисляет дисперсию элементов первой строки массива;" +
                                      "\n5) Программа считает количество чисел массива, попадающих в заданные интервалы ([-100; -50], [-50; 0], [0; 50], [50; 100]);" +
                                      "\n6) Программа складывает количество элементов массива, удовлетворяющих заданному условию (< 0);" +
                                      "\n7)" + @" Программа создаёт файл отчёта с указанным пользователем названием и открывает его для записи данных по пути S:\PRACTICA\Евтюхин К. О\Задание №5 - Учебная практика;" +
                                      "\n8) Программа автоматически записывает результаты выполнения функций в только что созданный пользователем файл отчёта, который затем автоматически закрывается;" +
                                      "\n9) Программа заканчивает свою работу при нажатии пользователем клавиши Esc." +
                                      "\n\n Инструкция:\n" +
                                      "\n1) Введите параметры для создания массива;" +
                                      "\n2) Введите название файла отчёта, в который будут записаны результаты;" +
                                      "\n3) Для выхода из программы нажмите клавишу Esc, затем подтвердите выбор нажатием на клавишу Enter.");
                    Console.WriteLine();
                }

                else if (UserKey.Key == ConsoleKey.Enter)
                {
                    Console.WriteLine();
                }

                else if (UserKey.Key == ConsoleKey.Escape)
                {
                    SkipUserKeyToExit = true;
                    CommandToExit(SkipUserKeyToExit);
                }

                else
                {
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine("Пожалуйста, нажмите клавишу F1 для вывода справки, или Enter для продолжения выполнения хода программы, или Esc для выхода из программы: ");
                    HelpAndStart(out SkipUserKeyToExit);
                }

                return;
            }

            // Функция, принимающая на вход параметры массива, которая также проверяет правильность введённых данных (функция, обрабатывающая исключения)
            public static void MassiveSizeInput(ref int N, ref int M, ref int K)
            {
                int ArgumentIsCorrectTimes = 0; // переменная, считающая сколько введено верных параметров массива

                while (ArgumentIsCorrectTimes != 3)
                {
                    while (ArgumentIsCorrectTimes == 0)
                    {
                        Console.WriteLine();
                        Console.WriteLine("Введите кол-во строк (N):");

                        try
                        {
                            N = int.Parse(Console.ReadLine());

                            if ((N <= 0) || (N > 1000))
                            {
                                throw new Exception();
                            }

                            else if (N is int)
                            {
                                ArgumentIsCorrectTimes++;
                            }
                        }

                        catch (System.FormatException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Формат числа задан некорректно. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }

                        catch (System.OverflowException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Введено число, превышающее лимит типа int. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }

                        catch (Exception)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Введено число, не подходящее для создания массива. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }
                    }

                    while (ArgumentIsCorrectTimes == 1)
                    {
                        Console.WriteLine();
                        Console.WriteLine("Введите кол-во столбцов (M):");

                        try
                        {
                            M = int.Parse(Console.ReadLine());

                            if ((M <= 0) || (M > 1000))
                            {
                                throw new Exception();
                            }

                            else if (M is int)
                            {
                                ArgumentIsCorrectTimes++;
                            }
                        }

                        catch (System.FormatException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Формат числа задан некорректно. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }

                        catch (System.OverflowException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Введено число, превышающее лимит типа int. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }

                        catch (Exception)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Введено число, не подходящее для создания массива. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }
                    }

                    while (ArgumentIsCorrectTimes == 2)
                    {
                        Console.WriteLine();
                        Console.WriteLine("Введите кол-во страниц (K):");

                        try
                        {
                            K = int.Parse(Console.ReadLine());

                            if ((K <= 0) || (K > 1000))
                            {
                                throw new Exception();
                            }

                            else if (K is int)
                            {
                                ArgumentIsCorrectTimes++;
                            }
                        }

                        catch (System.FormatException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Формат числа задан некорректно. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }

                        catch (System.OverflowException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Введено число, превышающее лимит типа int. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }

                        catch (Exception)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Введено число, не подходящее для создания массива. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }
                    }
                }

                Console.WriteLine();
            }

            // Функция, выполняющая выход из программы при подтверждении пользователем
            public static void CommandToExit(bool SkipUserKeyToExit)
            {
                Console.WriteLine();

                if (!SkipUserKeyToExit)
                {
                    Console.WriteLine("Программа завершила свою работу. Для выхода нажмите клавишу Esc.");
                    Console.WriteLine();
                    ConsoleKeyInfo UserKeyToExit = Console.ReadKey(true);

                    while (UserKeyToExit.Key != ConsoleKey.Escape)
                    {
                        UserKeyToExit = Console.ReadKey(true);
                    }

                    if (UserKeyToExit.Key == ConsoleKey.Escape)
                    {
                        Console.WriteLine("Вы уверены, что хотите выйти из программы? Подтвердите выход из программы нажатием на клавишу Enter. Для того, чтобы вернуться, нажмите клавишу Esc.");
                        ConsoleKeyInfo UserConfirmToExit = Console.ReadKey(true);

                        if (UserConfirmToExit.Key == ConsoleKey.Enter)
                        {
                            Environment.Exit(0);
                        }

                        else if (UserConfirmToExit.Key == ConsoleKey.Escape)
                        {
                            CommandToExit(SkipUserKeyToExit);
                        }

                        while ((UserConfirmToExit.Key != ConsoleKey.Escape) && (UserConfirmToExit.Key != ConsoleKey.Enter)) // Предотвращает нажатие посторонних клавиш пользователем
                        {
                            UserConfirmToExit = Console.ReadKey(true);

                            if (UserConfirmToExit.Key == ConsoleKey.Enter)
                            {
                                Environment.Exit(0);
                            }

                            else if (UserConfirmToExit.Key == ConsoleKey.Escape)
                            {
                                CommandToExit(SkipUserKeyToExit);
                            }
                        }
                    }
                }

                if (SkipUserKeyToExit)
                {
                    Console.WriteLine("Вы уверены, что хотите выйти из программы? Подтвердите выход из программы нажатием на клавишу Enter. Для того, чтобы вернуться, нажмите клавишу Esc.");
                    ConsoleKeyInfo UserConfirmToExit = Console.ReadKey(true);

                    if (UserConfirmToExit.Key == ConsoleKey.Enter)
                    {
                        Environment.Exit(0);
                    }

                    else if (UserConfirmToExit.Key == ConsoleKey.Escape)
                    {
                        Console.WriteLine();
                        HelpAndStart(out SkipUserKeyToExit);
                    }

                    while ((UserConfirmToExit.Key != ConsoleKey.Escape) && (UserConfirmToExit.Key != ConsoleKey.Enter)) // Предотвращает нажатие посторонних клавиш пользователем
                    {
                        UserConfirmToExit = Console.ReadKey(true);

                        if (UserConfirmToExit.Key == ConsoleKey.Enter)
                        {
                            Environment.Exit(0);
                        }

                        else if (UserConfirmToExit.Key == ConsoleKey.Escape)
                        {
                            Console.WriteLine();
                            HelpAndStart(out SkipUserKeyToExit);
                        }
                    }
                }

            }
        }

        // Класс, содержащий функции создания файла отчёта и записи результатов программы в текст //
        public class ConvertererToText
        {
            public static void CreateTextFile(double Sum, double AverageValue, double Dispersion, int A1, int A2, int A3, int A4, int A5, string FileName)
            {
                int Correct = 0;

                string FileText = "Задание №5 - 'Массив', Выполнил - Евтюхин кирилл из ИСП 121" +
                    Environment.NewLine + $"Сумма всех чисел S = {Sum}" +
                    Environment.NewLine + $"Среднее значение O = {AverageValue}" +
                    Environment.NewLine + $"Дисперсия D = {Dispersion}" +
                    Environment.NewLine + $"Количество чисел в интервале [-100; -50]: {A1}" +
                    Environment.NewLine + $"Количество чисел в интервале [-50; 0]: {A2}" +
                    Environment.NewLine + $"Количество чисел в интервале [0; 50]: {A3}" +
                    Environment.NewLine + $"Количество чисел в интервале [50; 100]: {A4}" +
                    Environment.NewLine + $"Количество чисел меньше 0: {A5}";

                Console.WriteLine("Введите имя текстового файла отчёта латинскими буквами:");

                //while (Correct == 0)
                //{
                    //try
                    //{
                        FileName = Console.ReadLine();

                        //if (FileName is string)
                        //{
                            //Correct++;
                        //}
                    //}

                    //catch ()
                    //{
                        //Console.WriteLine("Формат имени задан неккоректно. Пожалуйста, введите имя текстового файла отчёта латинскими буквами:");
                    //}
                //}

                string FilePath = @$"S:\PRACTICA\Евтюхин К. О\Задание №5 - Учебная практика\{FileName}.txt";

                File.AppendAllText(FilePath, FileText);
                Console.WriteLine();



                /*using (FileStream fs = File.Create(FilePath))
                {
                    //tw.WriteLine("KEK");
                    tw.Close();
                }*/

                /*using (StreamWriter writer = new StreamWriter(FilePath, false))
                {
                    writer.WriteLine(text);
                }*/
            }

            // Функция, создающая текстовый файл
            /*public static void CreateTextFile()
            {
                // Проверка правильности пути (символов - типом char или string - строка!!!)
                Console.WriteLine();
                string FileText = "Текст файла";
                Console.WriteLine(@"Введите имя текстового файла отчёта латинскими буквами (он будет располагаться по пути 'S:\PRACTICA\Евтюхин К. О\Задание №5 - Учебная практика'):");
                string FileName = Console.ReadLine(); // перехват ошибок!!!

                string FilePath = @"S:\PRACTICA\Евтюхин К. О\Задание №5 - Учебная практика";
                {
                    try
                    {
                        // Create the file, or overwrite if the file exists.
                        /*using (FileStream fs = File.Create(FilePath))
                        {
                            byte[] info = new UTF8Encoding(true).GetBytes("This is some text in the file.");
                            // Add some information to the file.
                            fs.Write(info, 0, info.Length);
                            //fs.Write(FileText);
                            fs.Close();
                        }

                        using (StreamWriter sw = File.CreateText())
                        {
                            sw.WriteLine("Hello");
                            sw.WriteLine("And");
                            sw.WriteLine("Welcome");
                        }

                        // Open the stream and read it back.
                        using (StreamReader sr = File.OpenText(FilePath))
                        {
                            string s = "";
                            while ((s = sr.ReadLine()) != null)
                            {
                                Console.WriteLine(s);
                            }
                        }

                        // File.AppendAllText(File_name_1, s + Environment.NewLine);
                    }

                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                    }*/

            /*Console.Write("Введите имя текстового файла отчёта латинскими буквами:");
            string PathToText = Console.ReadLine();

            try
            {
                TextpathDialog = File.ReadAllText(PathToText);
                Console.ReadLine();
            }

            catch (System.IO.FileNotFoundException)
            {
                Console.WriteLine("Путь файла указан некорректно. Повторно укажите путь к файлу: ");
                TextpathDialog();
                return;
            }
        }

        private static void PathDialog()
        {
            Console.Write("Укажите директорию файла отчёта: ");
            FilePath = Console.ReadLine() + @"\";
            FileName1 = FilePath + FileName0;
        }

        public static void FileWriteLine(string ???)
        {
            try
            {
                File.AppendAllText(FileName1, ??? + Environment.???Line)
            }

            catch (System.IO.DirectoryNotFoundException)
            {
                Console.WriteLine("Путь файла указан некорректно. Повторно укажите путь к файлу: ");
                PathDialog();
                FileWriteLine(???);
                return;
            }

            Console.WriteLine(???);
        }





        private static void TextPathDialog() // метод указание пути к файлу с текстом
        {
            Console.Write("Укажите путь к файлу с текстом (файл называется text1.txt): "); // путь к текстовому файлу-исходнику
            var Path_to_text = Console.ReadLine(); // @"S:\PRACTICA\Ivan Telegin\text1.txt"
            try
            {
                text = File.ReadAllText(Path_to_text);
                Console.ReadLine();
            }
            catch (System.IO.FileNotFoundException)
            {
                Console.WriteLine("Некорректно введен путь файла с текстом, укажите повторно путь к файлу."); // путь к текстовому файл-исходнику повтор
                TextPathDialog();
                return;
            }
            catch (System.ArgumentException)
            {
                Console.WriteLine("Не вписан путь файла с текстом, укажите повторно путь к файлу."); // путь к текстовому файл-исходнику повтор
                TextPathDialog();
                return;
            }
        }

        private static void PathDialog() // метод указание пути к файлу
        {
            Console.Write("Укажите директорию файла-отчета: "); // путь
            File_path = Console.ReadLine() + @"\";
            File_name_1 = File_path + File_name_0; // Компановка файла + пути
            }*/
            //  }
        }
    }
}