﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание__5___Учебная_практика
{
    // Класс, содержащий функцию Main, которая выводит значения //
    class Task_5___Educational_Practice
    {
        /* Переменные

        .................................

        int N - количество строк тёхмерного массива
        int M - количество столбцов тёхмерного массива
        int K - количество страниц (слоёв) трёхмерного массива

        double average - среднее значение элементов массива
        int elementsamount - количество элементов массива

        int a1 - количество чисел, входящих в диапазон: [-100; -50]
        int a2 - количество чисел, входящих в диапазон: [-50; 0]
        int a3 - количество чисел, входящих в диапазон: [0; 50]
        int a4 - количество чисел, входящих в диапазон: [50; 100]

        int a5 - количество чисел, удовлетворяющих условию: < 0

        double[,,] arr - сам трёхмерный массив

        ?????

        ConsoleKey UserKeyToExit - считывание введённой пользователем клавиши для выхода из программы
        ConsoleKeyInfo UserConfirmToExit - считывание клавиши, подтверждающей выход из программы

        int A - минимальная граница случайного числа элемента массива
        int B - максимальная граница случайного числа элемента массива

        Random rand - переменная, отвечающая за выборку случайных чисел

        int i, int j, int k - стандартные переменные для циклов (а также - индекс страницы / столбца / строки)

        double S - сумма всех элементов массива

        int E - количество элементов массива

        int O - среднее значение элементов массива

        double C - сумма квадратов разницы между элементами первой строки массива и средним значением элементов массива

        double D - дисперсия чисел первой строки

        double F - заданный элемент массива

        double G - заданный элемент массива

        ConsoleKeyInfo UserKey - считывание клавиши, которую ввёл пользователь

        int ArgumentIsCorrectTimes - количество верно введённых пользователем форматов переменных

        ..............

        */

        // Основная функция - в ней выводятся значения функций //
        static void Main(string[] args)
        {
            Console.Title = "Программа для выполнения практического задания №5 - Евтюхин Кирилл из ИСП 121";

            bool SkipForCommandToExit;
            bool SkipUserKeyToExit = false;
            //ConsoleKeyInfo UserKeyToExit = Console.ReadKey();

            int N = 0;
            int M = 0;
            int K = 0;

            double average;
            int elementsamount;

            int a1 = 0;
            int a2 = 0;
            int a3 = 0;
            int a4 = 0;

            int a5 = 0;

            Processing.HelpAndStart(out SkipForCommandToExit);

            Console.WriteLine("Задайте 3-х мерный массив:");
            Processing.MassiveSizeInput(ref N, ref M, ref K);

            Console.WriteLine("Массив:");

            double[,,] arr = new double[K, N, M];

            MathFunctions.FillAndShowMatrix(arr);

            MathFunctions.FindSummAndAverage(arr, out average, out elementsamount, ref N, ref M, ref K);

            MathFunctions.Dispersion(arr, average, elementsamount);

            MathFunctions.NumbersByInterval(arr, a1, a2, a3, a4);

            MathFunctions.NumbersBellowZero(arr, a5);

            //ConvertererToText.CreateTextFile();

            Processing.CommandToExit(SkipForCommandToExit, SkipUserKeyToExit);

            //Console.ReadKey(); //Убрать!
        }

        // Класс, содержащий математические и расчётные функции //
        public class MathFunctions
        {
            // Функция, заполняющая элементы массива (матрицы) случайными числами
            public static void FillAndShowMatrix(double[,,] arr, int A = -1005, int B = 1105)
            {
                Console.WriteLine();

                Random rand = new Random();

                // Страница
                for (int i = 0; i < arr.GetLength(0); i++)
                {
                    Console.WriteLine("Страница №: " + (i + 1));

                    // Строка
                    for (int j = 0; j < arr.GetLength(1); j++)
                    {
                        // Столбец
                        for (int k = 0; k < arr.GetLength(2); k++)
                        {
                            arr[i, j, k] = rand.Next(A, B) / 10.0; // заполнение массива элементом, которое мы не видим

                            if ((k + 1) == arr.GetLength(2)) // анализ того, является ли заполняемый элемент массива последним в строке
                            {
                                Console.Write($"{arr[i, j, k]}"); // вывод на экран элемента массива, являющегося последним на строке
                            }

                            else
                            {
                                Console.Write($"{arr[i, j, k]} "); // вывод элемента массива на экран, при условии, что он не является последнем на строке
                            }
                        }

                        Console.WriteLine();
                    }

                    Console.WriteLine();
                }
            }

            // Функция, которая находит сумму и среднее значение элементов массива
            public static void FindSummAndAverage(double[,,] arr, out double average, out int elementsamount, ref int N, ref int M, ref int K, double S = 0)
            {
                for (int i = 0; i < arr.GetLength(0); i++)
                {
                    for (int j = 0; j < arr.GetLength(1); j++)
                    {
                        for (int k = 0; k < arr.GetLength(2); k++)
                        {
                            S += arr[i, j, k];
                        }
                    }
                }

                int E = N * M * K; // умножение количества строк, столбцов и страниц для вычисления объёма массива
                double O = S / E; // вычисление среднего арифметического по всем элементам массива
                Console.WriteLine($"Сумма всех чисел (S): {Math.Round(S, 2)}");
                Console.WriteLine($"Среднее значение (O): {Math.Round(O, 2)}");

                average = O;
                elementsamount = E;
            }

            // Функция, которая находит дисперсию элементов первой строки массива
            public static void Dispersion(double[,,] arr, double average, int elementsamount, double C = 0)
            {
                for (int i = 0; i < 1; i++)
                {
                    for (int j = 0; j < 1; j++)
                    {
                        for (int k = 0; k < arr.GetLength(2); k++)
                        {
                            C += Math.Pow(arr[i, j, k] - average, 2); // вычисление суммы квадратов разницы между элементами первой строки и средним значением массива
                        }
                    }
                }

                double D = C / (elementsamount - 1); // вычисление дисперсии элементов первой строки
                Console.WriteLine($"Дисперсия (D): {Math.Round(D, 3)}"); // Нужно иметь в виду, что в сотых долях будет погрешность (поскольку это допускает сам тип данных double)!
            }

            // Функция, которая находит числа в заданных интервалах
            public static void NumbersByInterval(double[,,] arr, int a1, int a2, int a3, int a4)
            {
                for (int i = 0; i < arr.GetLength(0); i++)
                {
                    for (int j = 0; j < arr.GetLength(1); j++)
                    {
                        for (int k = 0; k < arr.GetLength(2); k++)
                        {
                            double F = arr[i, j, k]; // извлечение значения элемента массива

                            if ((-100 <= F) && (F <= -50))
                            {
                                a1++;
                            }

                            if ((-50 <= F) && (F <= 0))
                            {
                                a2++;
                            }

                            if ((0 <= F) && (F <= 50))
                            {
                                a3++;
                            }

                            if ((50 <= F) && (F <= 100))
                            {
                                a4++;
                            }
                        }
                    }
                }

                Console.WriteLine($"Кол-во чисел в интервале [-100; -50]: {a1}");
                Console.WriteLine($"Кол-во чисел в интервале [-50; 0]: {a2}");
                Console.WriteLine($"Кол-во чисел в интервале [0; 50]: {a3}");
                Console.WriteLine($"Кол-во чисел в интервале [50; 100]: {a4}");
            }

            // Функция, которая считает числа, удовлетворяющие условию
            public static void NumbersBellowZero(double[,,] arr, int a5)
            {
                for (int i = 0; i < arr.GetLength(0); i++)
                {
                    for (int j = 0; j < arr.GetLength(1); j++)
                    {
                        for (int k = 0; k < arr.GetLength(2); k++)
                        {
                            double G = arr[i, j, k]; // извлечение значения элемента массива

                            if (G < 0)
                            {
                                a5++;
                            }
                        }
                    }
                }

                Console.WriteLine($"Кол-во чисел меньше 0: {a5}");
            }
        }

        // Класс, содержащий программные и системные функции //
        public class Processing
        {
            // Функция, вызывающая справку, которая также не позволяет пользователю вводить некорректные символы во избежания ошибок (функция, обрабатывающая исключения)
            public static void HelpAndStart(out bool SkipForCommandToExit)
            {
                SkipForCommandToExit = false;
                bool SkipUserKeyToExit = false;

                Console.WriteLine("Для просмотра сведений о программе, поставленных перед ней задач, а также интструкции нажмите клавишу F1" +
                    "\nЕсли это не требуется, нажмите клавишу Enter" +
                    "\nДля выхода из программы нажмите клавишу Esc");

                ConsoleKeyInfo UserKey = Console.ReadKey(true); // считывание нажатой пользователем клавиши

                if (UserKey.Key == ConsoleKey.F1)
                {
                    Console.WriteLine("\nЗадание №5 - 'Массив', Выполнил - Евтюхин кирилл из ИСП 121" +
                                      "\n\n Задачи:\n" +
                                      "\n1) Программа строит массив по заданным пользователем параметрам;" +
                                      "\n2) Программа находит сумму всех элементов массива;" +
                                      "\n3) Программа расчитывает среднее значение всех элементов массива;" +
                                      "\n4) Программа вычисляет дисперсию элементов первой строки массива;" +
                                      "\n5) Программа считает количество чисел массива, попадающих в заданные интервалы([-100; -50], [-50; 0], [0; 50], [50; 100]);" +
                                      "\n6) Программа складывает количество элементов массива, удовлетворяющих заданному условию (< 0);" +
                                      "\n7)" + @" Программа создаёт и открывает для редактирования файл отчёта для записи с указанным названием по пути S:\PRACTICA\Евтюхин К. О\Задание №5 - Учебная практика;" +
                                      "\n8) Программа автоматически записывает результаты выполнения в только что созданный пользователем файл отчёта, который затем автоматически закрывает;" +
                                      "\n9) Программа выводит в консоли для пользователя данные из файла отчёта;" +
                                      "\n10) Программа заканчивает свою работу при нажатии пользователем клавиши Esc." +
                                      "\n\n Инструкция:\n" +
                                      "\n1) Введите параметры для создания массива;" +
                                      "\n2) Введите название файла отчёта, куда будет введён текст; \n   (Вместе с названием нужно будет написать расширение “txt”?????????)" +
                                      "\n3) Нажмите клавишу Esc, затем подтвердите выбор нажатием на клавишу Enter для выхода из программы.");
                    Console.WriteLine();
                }

                else if (UserKey.Key == ConsoleKey.Enter)
                {
                    Console.WriteLine();
                }

                else if (UserKey.Key == ConsoleKey.Escape)
                {
                    SkipForCommandToExit = true;
                    CommandToExit(SkipForCommandToExit, SkipUserKeyToExit);
                }

                else
                {
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine("Пожалуйста, нажмите клавишу F1 или Enter: ");
                    HelpAndStart(out SkipForCommandToExit);
                }

                return;
            }

            // Функция, принимающая на вход задающие размер массива числа, которая также проверяет правильность введённых данных в качестве пераметров массива (функция, обрабатывающая исключения)
            public static void MassiveSizeInput(ref int N, ref int M, ref int K)
            {
                int ArgumentIsCorrectTimes = 0; // переменная, считающая сколько введено верных параметров массива

                while (ArgumentIsCorrectTimes != 3)
                {
                    while (ArgumentIsCorrectTimes == 0)
                    {
                        Console.WriteLine();
                        Console.WriteLine("Введите кол-во строк (N):");

                        try
                        {
                            N = int.Parse(Console.ReadLine());

                            if ((N <= 0) || (N > 1000))
                            {
                                throw new Exception();
                            }

                            else if (N is int)
                            {
                                ArgumentIsCorrectTimes++;
                            }
                        }

                        catch (System.FormatException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Формат числа задан некорректно. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }

                        catch (System.OverflowException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Введено число, превышающее лимит типа int. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }

                        catch (Exception)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Введено число, не подходящее для создания массива. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }
                    }

                    while (ArgumentIsCorrectTimes == 1)
                    {
                        Console.WriteLine();
                        Console.WriteLine("Введите кол-во столбцов (M):");

                        try
                        {
                            M = int.Parse(Console.ReadLine());

                            if ((M <= 0) || (M > 1000))
                            {
                                throw new Exception();
                            }

                            else if (M is int)
                            {
                                ArgumentIsCorrectTimes++;
                            }
                        }

                        catch (System.FormatException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Формат числа задан некорректно. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }

                        catch (System.OverflowException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Введено число, превышающее лимит типа int. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }

                        catch (Exception)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Введено число, не подходящее для создания массива. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }
                    }

                    while (ArgumentIsCorrectTimes == 2)
                    {
                        Console.WriteLine();
                        Console.WriteLine("Введите кол-во страниц (K):");

                        try
                        {
                            K = int.Parse(Console.ReadLine());

                            if ((K <= 0) || (K > 1000))
                            {
                                throw new Exception();
                            }

                            else if (K is int)
                            {
                                ArgumentIsCorrectTimes++;
                            }
                        }

                        catch (System.FormatException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Формат числа задан некорректно. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }

                        catch (System.OverflowException)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Введено число, превышающее лимит типа int. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }

                        catch (Exception)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Введено число, не подходящее для создания массива. Пожалуйста, введите целое число в диапазоне [1; 1000].");
                        }
                    }
                }

                Console.WriteLine();
            }

            // Функция, выполняющая выход из программы при подтверждении этого пользователем
            public static void CommandToExit(bool SkipForCommandToExit, bool SkipUserKeyToExit)
            {
                Console.WriteLine();

                if (!SkipForCommandToExit)
                {
                    ConsoleKeyInfo UserKeyToExit = Console.ReadKey(true);

                    if (UserKeyToExit.Key == ConsoleKey.Escape)
                    {
                        Console.WriteLine("Вы уверены, что хотите выйти из программы? Подтвердите выход из программы нажатием на клавишу Enter. Для того, чтобы вернуться, нажмите клавишу Esc.");

                        ConsoleKeyInfo UserConfirmToExit = Console.ReadKey(true);

                        if (UserConfirmToExit.Key == ConsoleKey.Enter)
                        {
                            Environment.Exit(0);
                        }

                        else if (UserConfirmToExit.Key == ConsoleKey.Escape)
                        {
                            Console.WriteLine();
                        }

                        while ((UserConfirmToExit.Key != ConsoleKey.Escape && UserConfirmToExit.Key != ConsoleKey.Enter)) // Предотвращает нажатие посторонних клавиш пользователем
                        {
                            UserConfirmToExit = Console.ReadKey(true);

                            if (UserConfirmToExit.Key == ConsoleKey.Enter)
                            {
                                Environment.Exit(0);
                            }

                            else if (UserConfirmToExit.Key == ConsoleKey.Escape)
                            {
                                Console.WriteLine();
                            }
                        }
                    }
                }

                if (SkipForCommandToExit)
                {
                    Console.WriteLine("Вы уверены, что хотите выйти из программы? Подтвердите выход из программы нажатием на клавишу Enter. Для того, чтобы вернуться, нажмите клавишу Esc.");

                    ConsoleKeyInfo UserConfirmToExit = Console.ReadKey(true);

                    if (UserConfirmToExit.Key == ConsoleKey.Enter)
                    {
                        Environment.Exit(0);
                    }

                    else if (UserConfirmToExit.Key == ConsoleKey.Escape)
                    {
                        Console.WriteLine();
                    }

                    while ((UserConfirmToExit.Key != ConsoleKey.Escape && UserConfirmToExit.Key != ConsoleKey.Enter)) // Предотвращает нажатие посторонних клавиш пользователем
                    {
                        UserConfirmToExit = Console.ReadKey(true);

                        if (UserConfirmToExit.Key == ConsoleKey.Enter)
                        {
                            Environment.Exit(0);
                        }

                        else if (UserConfirmToExit.Key == ConsoleKey.Escape)
                        {
                            Console.WriteLine();
                        }
                    }
                }


            }
        }

        // Класс, содержащий функции создания файла отчёта и записи результатов программы в текст //
        public class ConvertererToText
        {
            //static string FilePath;
            static string FileName0;
            static string FileName1;

            // Функция, создающая текстовый файл
            public static void CreateTextFile()
            {
                // Проверка правильности пути (символов - типом char или string - строка!!!)
                Console.WriteLine();
                string FileText = "Текст файла";
                Console.WriteLine(@"Введите имя текстового файла отчёта латинскими буквами (он будет располагаться по пути 'S:\PRACTICA\Евтюхин К. О\Задание №5 - Учебная практика'):");
                string FileName = Console.ReadLine(); // перехват ошибок!!!

                string FilePath = @"S:\PRACTICA\Евтюхин К. О\Задание №5 - Учебная практика";
                {
                    try
                    {
                        // Create the file, or overwrite if the file exists.
                        using (FileStream fs = File.Create(FilePath))
                        {
                            //byte[] info = new UTF8Encoding(true).GetBytes("This is some text in the file.");
                            // Add some information to the file.
                            //fs.Write(info, 0, info.Length);
                            //fs.Write(FileText);
                            fs.Close();
                        }

                        // Open the stream and read it back.
                        using (StreamReader sr = File.OpenText(FilePath))
                        {
                            string s = "";
                            while ((s = sr.ReadLine()) != null)
                            {
                                Console.WriteLine(s);
                            }
                        }

                        //File.AppendAllText(File_name_1, s + Environment.NewLine);
                    }

                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                    }

                    /*catch (System.IO.DirectoryNotFoundException)
                    {
                        Console.WriteLine("Некорректно введен путь файла-отчета, укажите повторно путь к файлу."); // путь к текстовому файл-отчету повтор
                        PathDialog();
                        File_WriteLine(s);
                        return;
                    }
                    Console.WriteLine(s);*/
                }
                /*Console.Write("Введите имя текстового файла отчёта латинскими буквами:");
                string PathToText = Console.ReadLine();

                try
                {
                    TextpathDialog = File.ReadAllText(PathToText);
                    Console.ReadLine();
                }

                catch (System.IO.FileNotFoundException)
                {
                    Console.WriteLine("Путь файла указан некорректно. Повторно укажите путь к файлу: ");
                    TextpathDialog();
                    return;
                }
            }

            private static void PathDialog()
            {
                Console.Write("Укажите директорию файла отчёта: ");
                FilePath = Console.ReadLine() + @"\";
                FileName1 = FilePath + FileName0;
            }

            public static void FileWriteLine(string ???)
            {
                try
                {
                    File.AppendAllText(FileName1, ??? + Environment.???Line)
                }

                catch (System.IO.DirectoryNotFoundException)
                {
                    Console.WriteLine("Путь файла указан некорректно. Повторно укажите путь к файлу: ");
                    PathDialog();
                    FileWriteLine(???);
                    return;
                }

                Console.WriteLine(???);
            }





            private static void TextPathDialog() // метод указание пути к файлу с текстом
            {
                Console.Write("Укажите путь к файлу с текстом (файл называется text1.txt): "); // путь к текстовому файлу-исходнику
                var Path_to_text = Console.ReadLine(); // @"S:\PRACTICA\Ivan Telegin\text1.txt"
                try
                {
                    text = File.ReadAllText(Path_to_text);
                    Console.ReadLine();
                }
                catch (System.IO.FileNotFoundException)
                {
                    Console.WriteLine("Некорректно введен путь файла с текстом, укажите повторно путь к файлу."); // путь к текстовому файл-исходнику повтор
                    TextPathDialog();
                    return;
                }
                catch (System.ArgumentException)
                {
                    Console.WriteLine("Не вписан путь файла с текстом, укажите повторно путь к файлу."); // путь к текстовому файл-исходнику повтор
                    TextPathDialog();
                    return;
                }
            }

            private static void PathDialog() // метод указание пути к файлу
            {
                Console.Write("Укажите директорию файла-отчета: "); // путь
                File_path = Console.ReadLine() + @"\";
                File_name_1 = File_path + File_name_0; //Компановка файла + пути
                }*/
            }
        }
    }
}